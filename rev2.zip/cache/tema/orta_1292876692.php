<?php if(!defined('IN_RAINTPL')){exit('Ne işin var burda?');}?>﻿<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"

"http://www.w3.org/TR/html4/loose.dtd">

<html>

<head>

<meta http-equiv="Content-Type" content="text/html; charset=WINDOWS-1254">

<SCRIPT src="tema/<?php  echo $var["TEMADIR"];?>/images/top.js" type=text/javascript></SCRIPT>

<SCRIPT language=javascript src="tema/images/sozluk.js"></SCRIPT>

<LINK href="favicon.ico" rel="shortcut Icon"><LINK href="favicon.ico" rel=icon>

<LINK href="<?php  echo $var["TEMADIR"];?>/images/sozluk.css" type=text/css rel=stylesheet>

<LINK href="<?php  echo $var["TEMADIR"];?>/images/default.css" type=text/css rel=stylesheet>

</head>



<body>

<SCRIPT type="text/javascript" src="tema/1_dosyalar/jquery-1.3.2.min.js"></SCRIPT>

          <DIV style="OVERFLOW-X: hidden; WIDTH: 100%; HEIGHT: 100%">
<!-- google_ad_section_start -->

<meta name="keywords" content="sözlük nokta cc">

<meta name="description" content="sözlük nokta cc">

<title>sözlük nokta cc</title><br><br>

         <span class="title">

     <a href="sozluk.html">sözlük</a> </span>

    

         <span class="title">

     <a href="nokta.html">nokta</a> </span>

    

         <span class="title">

     <a href="cc.html">cc</a> </span>

    <br>   

  </FONT>

      </TD>

</TR></TBODY></TABLE>





<DIV class=panel id=panel style="FLOAT: right">



<fieldset class='highlight'><a target=main href="sozluk.php?process=onlinee"><b>kimler var?</b></a></fieldset>

<script type='text/javascript'>ors('sözlük nokta cc');</script>



    <style type='text/css'>

.aratext

{

  width:100%;

}

</style>

</p>

<tr>

<td align=right>


</td>

</tr> 

</TABLE></DIV>







<OL>





  <li value=1 id="d1"><DIV class=eol><font size=2>naber lan</DIV>

  

  <DIV align=left> <div class="aul"><font size=1>[<A href="admin.html" title="admin">admin</A></B>, 12.10.2010 20:02]   <script language="javascript">zyrt(252,1,'admin');</SCRIPT>

  </font></DIV></li></font>





  <li value=2 id="d2"><DIV class=eol><font size=2>(bkz: <a href=".html" title="(bkz: )"><b></b></a>)</DIV>

  

  <DIV align=left> <div class="aul"><font size=1>[<A

  href="admin.html" title="admin">admin</A></B>, 28.10.2010 13:08]   <script language="javascript">zyrt(252,2,'admin');</SCRIPT>

  </font></DIV></li></font>





  <li value=3 id="d5"><DIV class=eol><font size=2>  &<a href=sozluk.php?process=eid&eid=9650>#9650</a>;

<br>&<a href=sozluk.php?process=eid&eid=9650>#9650</a>; &<a href=sozluk.php?process=eid&eid=9650>#9650</a>;
<br>deneme</DIV>

  

  <DIV align=left> <div class="aul"><font size=1>[<A

  href="admin.html" title="admin">admin</A></B>, 23.11.2010 23:29]   <script language="javascript">zyrt(252,5,'admin');</SCRIPT>

  </font></DIV></li></font>

</div></body>
</html>

<br /><br /><br /><br /><br /><center><a href=sozluk.php?process=word&q=sozluk+sözlük target=main><font size=1>sozluk sözlük topluluğu</font></a>

<hr>



<font size=1><a href="sozluk+sözlük.html">sozluk sözlük</a><br>

<a href="sozluk.php?process=sikayetgiris">Yönetimle İletiseyim</a>


</body>

</html>

