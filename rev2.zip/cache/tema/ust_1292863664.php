<?php if(!defined('IN_RAINTPL')){exit('Ne işin var burda?');}?>﻿<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"

"http://www.w3.org/TR/html4/loose.dtd">

<html>

<head>

<meta http-equiv="Content-Type" content="text/html; charset=WINDOWS-1254">

<SCRIPT src="tema/<?php  echo $var["TEMADIR"];?>/images/top.js" type=text/javascript></SCRIPT>

<SCRIPT language=javascript src="tema/images/sozluk.js"></SCRIPT>

<LINK href="favicon.ico" rel="shortcut Icon"><LINK href="favicon.ico" rel=icon>

<LINK href="<?php  echo $var["TEMADIR"];?>/images/sozluk.css" type=text/css rel=stylesheet>

<LINK href="<?php  echo $var["TEMADIR"];?>/images/default.css" type=text/css rel=stylesheet>

</head>



<body>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
<META content=noarchive,nosnippet name=robots>
<SCRIPT src="tema/images/sozluk.js" type=text/javascript></SCRIPT>
<SCRIPT src="tema/images/top.js" type=text/javascript></SCRIPT>

<LINK href="favicon.ico" rel="shortcut Icon"><LINK href="favicon.ico" rel=icon>

<link rel="stylesheet" type="text/css" href="tema/.css" />
<title></title>
</head>
<body class="bgtop">
<table cellspacing="0" cellpadding="0" style="margin:0;padding:0">

	<tr>
    <TD width="150" noWrap onClick="top.main.location.href='sozluk.php?process=staff'">
    <img src="tema/images/logo.png" border=0 />    </TD>

   <td>
   <table cellpadding="0" cellspacing="1" class="nav">
<tr>

<td onMouseDown="md(this)" onMouseUp="bn(this)" onMouseOver="ov(this)" onMouseOut="bn(this)" class="but" onClick="top.main.location.href='rasgele/'"><a  title="kafana gore takıl hacı" target="main" href="rasgele.php">rastgele</a></td>
<td onMouseDown="md(this)" onMouseUp="bn(this)" onMouseOver="ov(this)" onMouseOut="bn(this)" class="but"><a title="belki ozleyeceksin ama" target="left" href="birgun.php">bir gün</a></td>
<td onMouseDown="md(this)" onMouseUp="bn(this)" onMouseOver="ov(this)" onMouseOut="bn(this)" class="but""><a title="kasiksiz karistir koc" target="left" href="karma.php">karma</a></td>
<td onMouseDown="md(this)" onMouseUp="bn(this)" onMouseOver="ov(this)" onMouseOut="bn(this)" class="but"><a title="iyisinden olsun.." target="main" href="sukela.php">miss gibi</a></td>
<td onMouseDown="md(this)" onMouseUp="bn(this)" onMouseOver="ov(this)" onMouseOut="bn(this)" class="but" colspan="1"><a title="en ilginc başlıklardan" target="main" href="enteresan.php">enteresan</a></td>
<td onMouseDown="md(this)" onMouseUp="bn(this)" onMouseOver="ov(this)" onMouseOut="bn(this)" class="but"><a title="kotusunden koy az.." target="main" href="shit.php">shit!</a></td>

 <td onmousedown="md(this) " onmouseup="bn(this) " onmouseover="ov(this) " onmouseout="bn(this) " class="but"><a target="main" href="giris.php">eleman girisi</a></td>
<td onmousedown="md(this) " onmouseup="bn(this) " onmouseover="ov(this) " onmouseout="bn(this) " class="but"><a title="sende mi yazar olmak istiyorsun.." target="main" href="register.php">Yeni Yazar?</a></td></TR>
<tr>

<td onMouseDown="md(this)" onMouseUp="bn(this)" onMouseOver="ov(this)" onMouseOut="bn(this)" class="but" ><a title="bugüne gelsin" target="left" href="bugun.php">bugün</a></td>
<td onMouseDown="md(this)" onMouseUp="bn(this)" onMouseOver="ov(this)" onMouseOut="bn(this)" class="but"><a title="düne gelsin" target="left" href="dun.php">dün</a></td>
<td onMouseDown="md(this)" onMouseUp="bn(this)" onMouseOver="ov(this)" onMouseOut="bn(this)" class="but"><a title="hayvanım ben tum ay lazım" target="left" href="buay.php">&nbsp;bu ay&nbsp;</a></td>
<td onMouseDown="md(this)" onMouseUp="bn(this)" onMouseOver="ov(this)" onMouseOut="bn(this)" class="but" colspan="1"><a title="istatistik verecem diye yırtınan şey" target="main" href="stat.php">istatistikler</a></td>
<td onmousedown="md(this) " onmouseup="bn(this) " onmouseover="ov(this) " onmouseout="bn(this) " class="but"><a title="soruluyor bunlar" target="main" href="faq.php">faq</a></td> 

<td colspan="3" style="margin:0;padding:0">
<table border="0" cellspacing="0" cellpadding="0">
<tr>
<td style="height:10px;white-space:nowrap;padding:1px;font-size:small">
<form action="sozluk.php?process=word" id="fg" method="post" target="main">
      <u>b</u>aşlık 
      <input class="input" style="height:12px" accesskey="a" id="q" name="q" size="30" />
</form></td>

<td onMouseDown="md(this)" onMouseUp="bn(this)" onMouseOver="ov(this)" onMouseOut="bn(this)" class="but" onClick="top.main.location.href='sozluk.php?process=word&q='+escape(document.getElementById('q').value);"><a href="javascript:document.getElementById('q').submit()">gelsin</a></td>
<td onMouseDown="md(this)" onMouseUp="bn(this)" onMouseOver="ov(this)" onMouseOut="bn(this)" class="but" onClick="top.main.javascript:ara();return false"><a  title="böyle birşey" href="javascript:ara()">ara</a></td>
<td onMouseDown="md(this)" onMouseUp="bn(this)" onMouseOver="ov(this)" onMouseOut="bn(this)" class="but" onClick="top.main.location.href='sozluk.php?process=eid&eid='+escape(document.getElementById('q').value);"><a href="javascript:document.getElementById('q').submit()">#id</td>

</tr></table></td></tr></table></td>
</tr></table>



</body>

</body>

</html>

