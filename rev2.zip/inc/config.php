<?php
$dbuser='root';
$dbsifre = '';
$dbadi ='proje2';
$dbhost = 'localhost';
?>