<?php
$dil = array(
/* KAYIT SAYFASI */
"KAYIT" => 
array(
"BOS_ALAN_DOLDUR" => '<a href="javascript: history.go(-1)">geri d�n</a>, mayk ve o bo� alanlar�n can�na oku, yoksa g�revin ba�ar�s�z olacak',
"GECERLI_NICK" => '<a href="javascript: history.go(-1)">geri d�n</a>, karde�im, sistem �ye ad�nda sadece ingilizce harfler, say�lar ve bo�lu�a izin �eediyor',
"NICK_KULLANIMDA" => '<a href="javascript: history.go(-1)">geri d�n</a>, ve ba�ka bir �ye ad� se�, bu ad� ba�ka birine verdik biz',
"MAIL_KULLANIMDA" => '<a href="javascript: history.go(-1)">geri d�n</a>, ve ba�ka bir email adresi se�, bu emaili ba�ka birine verdik biz',
"GECERSIZ_SIFRE" => '<a href="javascript: history.go(-1)">geri d�n</a>, �ifren en az 4 en fazla 16 karakter uzunlu�unda olmal�',
"UYUMSUZ_SIFRE" => '<a href="javascript: history.go(-1)">geri d�n</a>, yazd���n iki �ifre birbirine uymad� malesef',
"GECERSIZ_DOGUM_TARIHI" => '<a href="javascript: history.go(-1)">geri d�n</a>, ge�erli bir do�um tarihi gir.',

)
);
?>