<?php
function yazdir(){
echo 'test';
}
?>