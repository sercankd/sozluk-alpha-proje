<?php

// Ana Include Dosyas�
include ("inc/global.php");
switch ($_GET['islem']) {
    case 'kayit':
        if ($sozluk->Ayarlar("yeni_uye") == 1) {
            if (!$sozluk->BosAlanKontrol()) {
                $tpl->assign("HATA", $dil["KAYIT"]["BOS_ALAN_DOLDUR"]);
                echo $tpl->draw('kayit_hata');
            } else {
                if ($sozluk->GecerliNick($_POST['kuladi'])) { // Nick kontrol�
                    $tpl->assign("HATA", $dil["KAYIT"]["GECERLI_NICK"]);
                    echo $tpl->draw('kayit_hata');
                } elseif ($sozluk->NickKullanimdami($_POST['kuladi'])) { // Nick kullan�mdam� kontrol�
                    $tpl->assign("HATA", $dil["KAYIT"]["NICK_KULLANIMDA"]);
                    echo $tpl->draw('kayit_hata');
                } elseif ($sozluk->MailKullanimdami($_POST['email'])) { // Email kullan�mdam� kontrol�
                    $tpl->assign("HATA", $dil["KAYIT"]["MAIL_KULLANIMDA"]);
                    echo $tpl->draw('kayit_hata');
                } elseif ($sozluk->KayitSifreUzunlukKontrol($_POST['sifre'])) { // Ge�erli �ifre kontrol� (range 4-16)
                    $tpl->assign("HATA", $dil["KAYIT"]["GECERSIZ_SIFRE"]);
                    echo $tpl->draw('kayit_hata');
                } elseif (!$sozluk->KayitSifreKontrol($_POST['sifre'], $_POST['sifret'])) { //�ki �ifre uyumu
                    $tpl->assign("HATA", $dil["KAYIT"]["UYUMSUZ_SIFRE"]);
                    echo $tpl->draw('kayit_hata');
                } elseif (!$sozluk->DogumTarihiKontrol($_POST['dogumyili'])) { // Do�um y�l� kontrol�
                    $tpl->assign("HATA", $dil["KAYIT"]["GECERSIZ_DOGUM_TARIHI"]);
                    echo $tpl->draw('kayit_hata');
                } else {
                    $sozluk->YeniUyeKayit($db->escape($_POST['kuladi']), "test", md5($_POST['sifre']),
                        $_POST['email'], 0, $_POST['cinsiyet'], $_POST['dogumyili'], $db->escape($_POST['sehir']),
                        getIP(), getIP(), date("m.d.y H:i:s"), $sozluk->Ayarlar('kayit_nesil'));
                    $tpl->assign("KAYIT_NICK", $_POST['kuladi']);
                    echo $tpl->draw('kayitok');

                }
            }
        }
        break;
    case 'giris':
        if (isset($_POST['giris'])) {
            $nick = $db->escape($_POST['gnick']);
            $sifre = md5($db->escape($_POST['gsifre']));
            $login = $db->query("SELECT * FROM uyeler WHERE nick = '{$nick}' AND sifre = '{$sifre}'");
            if (!$login) {
                $tpl->assign("HATA", "Yanl�� kullan�c� ad� veya �ifre.");
                echo $tpl->draw('hata');
            } else {
                $tpl->assign("BILGI", "Giri� yapt���n�z nick: {$nick}, �imdi y�nlendiriliyorsunuz..");
                $_SESSION['nick'] = $_POST['gnick'];
                $_SESSION['loggedin'] = "1";
                echo $tpl->draw('bilgi');
            }
        }
        break;
    case 'cikis':
        unset($_SESSION['loggedin']);
        unset($_SESSION['nick']);
        $tpl->assign("BILGI", "��k�� yapt�n�z..");
        echo $tpl->draw('bilgi');
        break;
}

?>