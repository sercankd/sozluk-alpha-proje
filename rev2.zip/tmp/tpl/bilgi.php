<?php if(!class_exists('raintpl')){exit;}?><!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"><html><head>
<meta http-equiv="Content-Type" content="text/html; charset=WINDOWS-1254">
<meta http-equiv="Content-Language" content="tr" />
<title>neseli</title>
<meta name="title" content="<?php echo $SOZLUK_ADI;?>" />
<meta name="robots" content="index,follow,noarchive" />
<meta name="description" content="<?php echo $SOZLUK_ADI;?>" />
<meta name="keywords" content="<?php echo $SOZLUK_ADI;?>" />
<link rel="stylesheet" href="tpl/images/default.css" type="text/css" />
<script language="javascript" type="text/javascript">
<!--
top.frames["spsolkisim"].location.reload()
top.frames["spustkisim"].location.reload()
-->
</script> 
</head>
<body  >
<div style="margin:20px;margin-bottom:150px;"><div>
      <center><h4><img src="tpl/images/bilgi.png" /><?php echo $BILGI;?></h4></center>
</div>
</div>
</body>
</html>