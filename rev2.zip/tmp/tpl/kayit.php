<?php if(!class_exists('raintpl')){exit;}?><!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//TR"><html><head> 
<meta http-equiv="Content-Type" content="text/html; charset=WINDOWS-1254">
<meta http-equiv="Content-Language" content="tr" /> 
<title><?php echo $SOZLUK_ADI;?></title> 
<meta name="title" content="<?php echo $SOZLUK_ADI;?>" /> 
<meta name="robots" content="index,follow,noarchive" /> 
<meta name="description" content="<?php echo $SOZLUK_ADI;?>" /> 
<meta name="keywords" content="<?php echo $SOZLUK_ADI;?>" /> 
<link rel="stylesheet" href="tpl/images/default.css" type="text/css">
<link rel="icon" href="tpl//res/favicon.png" type="image/x-icon" /> 
<link rel="shortcut icon" href="tpl//res/favicon.png" type="image/x-icon" /> 
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script> 
<script src="tpl/js/lib.js" language="javascript" type="text/javascript" ></script> 
</head> 
<!--
sozlukspot.com up stats
server farm: kopernick
subd name: <?php echo $SOZLUK_ADI;?>
up exeqution time: 0.0001 sec
server id: 3
start time: 18.02.2011 01:32:55
--> 
<body  > 
<div style="margin:20px;margin-bottom:150px;"><div class="buyuk_baslik"><?php echo $SOZLUK_ADI;?> �yesi ol</div><div style="margin:10px;margin-left:0px;" >

  <table border="0" cellpadding="0" cellspacing="0" >

    <form name="yeniuye" action="islem.php?islem=kayit" method="post" onsubmit="return yeniuye_submit();" >

      <tr>

        <td>

		<table width="100%" border="0" cellpadding="3" cellspacing="0" class="msj_tablo_back">

             <tr>

              <td width="150" class="msj_ozel_tablo_1"><strong>�ye ad�n�z</strong></td>

              <td class="msj_ozel_tablo_2"><input name="kuladi" type="text" id="kuladi" value="" size="34" maxlength="30" >

                 <font ></font></td>

            </tr>

            <tr>

              <td  width="150" class="msj_ozel_tablo_1"><strong>�ifre:</strong></font></td>

              <td class="msj_ozel_tablo_2"><input name="sifre" type="password" id="sifre" value="" size="15" maxlength="50">

                 <font ></font>                </td>

            </tr>

            <tr>

              <td width="150" class="msj_ozel_tablo_1"><strong>�ifrenizi tekrar girin:</strong></td>

              <td class="msj_ozel_tablo_2"><input name="sifret" type="password" id="sifret" size="15" maxlength="50"></td>

            </tr>

            <tr>

              <td width="150" class="msj_ozel_tablo_1"><strong>e-posta:</strong></td>

              <td class="msj_ozel_tablo_2"><input name="email" type="text" id="email"  value="" size="35" >

                 <font ></font>                </td>

            </tr>

            <tr>

              <td width="150" class="msj_ozel_tablo_1"><strong>bulundu�unuz yer:</strong></td>

              <td class="msj_ozel_tablo_2"><input name="sehir" type="text" id="sehir" size="10" value="" >

                 <font ></font>              </td>

            </tr>

            <tr>

              <td width="150" class="msj_ozel_tablo_1"><strong>do�du�un y�l:</strong></td>

              <td class="msj_ozel_tablo_2"><input name="dogumyili" type="text" id="dogumyili" size="4" maxlength="4" value="19" >

                 <font ></font>              </td>

            </tr>

            <tr>

              <td width="150" class="msj_ozel_tablo_1"><strong>cinsiyet</strong></td>

              <td class="msj_ozel_tablo_2"><select name="cinsiyet" id="cinsiyet">

                  <option selected></option>

                  <option >erkek</option>

                  <option >kadin</option>

                  <option >ba�ka</option>

                </select>

                 <font ></font>              </td>

            </tr>


            <tr>

              <td colspan="2" class="msj_ozel_tablo_1">

              <div style="width:400px;color:#333333;font-size:10px;">

              <li><?php echo $SOZLUK_ADI;?> herkese a��k bir s�zl�k �al��mas�d�r. <?php echo $SOZLUK_ADI;?> giderek b�y�yen yazar kadrosuna yeni yazarlar katmak istemekte, bunun yan�nda mevcut yazar kalitesini de korumak istemektedir. bu sebeple <?php echo $SOZLUK_ADI;?> sitemizde yazar al�mlar� kontrol alt�nda tutulmaktad�r. <?php echo $SOZLUK_ADI;?> sitesinde yazar olmak i�in yukar�dakidaki formu doldurman�z gerekmektedir.</li>

              <li>bir <?php echo $SOZLUK_ADI;?> yazar� olabilmek i�in s�zl�k format� hakk�nda bilgi sahibi olman�z gereklidir. <?php echo $SOZLUK_ADI;?> sitesini ���nc� �ah�slara hakaret etmek i�in kullanmak s�zl�kten u�urulma sebebidir. s�zl�k'ten u�urulmamak i�in s�zl�k kurallar�na uyman�z gerekmektedir.</li>

              </div></td>

            </tr>

            <tr>

              <td width="150" class="msj_ozel_tablo_1"></td>

              <td class="msj_ozel_tablo_2">

                  <input type="submit" name="uyesubmit" value="      go go go      " />                 </td>

            </tr>

        </table></td>

      </tr>

    </form>

  </table>

</div>

<hr>

<div align="center">2011 &copy; <?php echo $SOZLUK_ADI;?> kay�t formu</div>

<script language="JavaScript" type="text/javascript">

	document.yeniuye.kuladi.focus();

	function yeniuye_submit(){

		var d = document.yeniuye;

		var reg = new RegExp("^([a-z0-9_]|\\-|\\.)+@((hotmsssail|\\-)+\\.)+[a-z]{2,4}$");

		if(d.email.value.search(reg) >= 0 ){

			return confirm("HOTMAIL'e g�nderilen aktivasyon kodlar� \"JUNK MAIL\" klas�r�ne gitmektedir.\nEmail adresi olarak HOTMAIL'den ba�ka email adresi girebiliyorsan�z girmenizi tavsiye ederiz.");

			d.email.focus();

		/*}else if(d.soz_kabul.checked!=true){

			alert("�yelik s�zle�mesini kabul etmelisiniz.");

			return false;*/

		}else{

			return true;

		}

	}

</script>

</div> 
<!--
sozlukspot.com stats
server farm: kopernick
subd name: <?php echo $SOZLUK_ADI;?>
exeqution time: 0.0048 sec
server id: 7
time: 18.02.2011 01:32:55
--> 
</body> 
</html> 