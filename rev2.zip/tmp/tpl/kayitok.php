<?php if(!class_exists('raintpl')){exit;}?><!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"><html><head>
<meta http-equiv="Content-Type" content="text/html; charset=WINDOWS-1254">
<meta http-equiv="Content-Language" content="tr" />
<title><?php echo $SOZLUK_ADI;?></title>
<meta name="title" content="<?php echo $SOZLUK_ADI;?>" />
<meta name="robots" content="index,follow,noarchive" />
<meta name="description" content="<?php echo $SOZLUK_ADI;?>" />
<meta name="keywords" content="<?php echo $SOZLUK_ADI;?>" />
<link rel="stylesheet" href="tpl/images/default.css" type="text/css">
<link rel="icon" href="tpl//res/favicon.png" type="image/x-icon" /> 
<link rel="shortcut icon" href="tpl//res/favicon.png" type="image/x-icon" /> 
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>
<script src="tpl//soy/ss_jslib.js" language="javascript" type="text/javascript" ></script>
</head>
<body  >
<div style="margin:20px;margin-bottom:150px;"><div class="buyuk_baslik"><?php echo $SOZLUK_ADI;?> kay�t formu</div><table width="450"><tr><td><div style="margin:15px;">Sevgili <u>sercankdmqm</u>, <br /> �yelik i�lemi tamamland�. <b>asdasdq@dispostable.com</b> adresine �yelik onaylanmans� i�in mail g�nderdik. �yeli�inin aktifle�mesi i�in g�nderilen emaildeki linke t�klamal�s�n. mail 1 dakika i�erisinde size ola�acakt�r. Hotmail,yahoo gibi baz� e-mail adreslerinde aktivasyon maili junk mail klas�r�nde olabilir. oray� da kontrol et.<br><br><br><a href="ss_index.php?sa=login">login</a> | <a href="ss_index.php?sa=uyelik&ne=aktimail">Maili Tekrar G�nder</a></div></td><tr></table></div>
</body>
</html>

