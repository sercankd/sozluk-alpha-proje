<?php if(!class_exists('raintpl')){exit;}?><!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"><html><head>
<meta http-equiv="Content-Type" content="text/html; charset=WINDOWS-1254">
<meta http-equiv="Content-Language" content="tr" />
<title>neseli</title>
<meta name="title" content="<?php echo $SOZLUK_ADI;?>" />
<meta name="robots" content="index,follow,noarchive" />
<meta name="description" content="<?php echo $SOZLUK_ADI;?>" />
<meta name="keywords" content="<?php echo $SOZLUK_ADI;?>" />
<link rel="stylesheet" href="tpl/images/default.css" type="text/css">
<link rel="icon" href="tpl//res/favicon.png" type="image/x-icon" /> 
<link rel="shortcut icon" href="tpl//res/favicon.png" type="image/x-icon" /> 
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>
<script src="tpl//soy/ss_jslib.js" language="javascript" type="text/javascript" ></script>
</head>
<!--
sozlukspot.com up stats
server farm: kopernick
subd name: neseli
up exeqution time: 0.0001 sec
server id: 7
start time: 18.02.2011 04:18:16
-->
<body  >
<div style="margin:20px;margin-bottom:150px;"><div>
      <h2><?php echo $SOZLUK_ADI;?> yazar al�m� �uan i�in kapal�d�r</h2>
      <div style="margin-left:5px;line-height:20px;"><b><?php echo $SOZLUK_ADI;?></b> olarak internetteki t�rk�e bilgi kayna�� eksikli�ini gidermek i�in yazarlar�m�zla gece g�nd�z �al��maktad�r. ancak yazarlar�m�z�n daha verimli olmas�n� sa�lamak i�in bir s�reli�ine yeni yazar al�m�n� durdurmu� bulunuyoruz. bu s�re zarf�nda <?php echo $SOZLUK_ADI;?> yazar� olmak i�in <?php echo $SOZLUK_ADI;?> �yeli�inin a��lmas�n� beklemelisiniz. ileti�im sayfas�ndan neseli ekibi ile ileti�ime ge�ip �ye olmak istedi�inizi bildirmek i�e yaramayacakt�r. l�tfen <?php echo $SOZLUK_ADI;?> �yeli�i a��lana kadar bekleyiniz.</div>
      <div style="margin-left:5px;margin-top:10px;line-height:20px;"><?php echo $SOZLUK_ADI;?> y�netimi</div>
</div>
</div>
<!--
sozlukspot.com stats
server farm: kopernick
subd name: neseli
exeqution time: 0.0034 sec
server id: 5
time: 18.02.2011 04:18:16
-->
</body>
</html>