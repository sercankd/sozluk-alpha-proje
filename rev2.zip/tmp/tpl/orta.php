<?php if(!class_exists('raintpl')){exit;}?>﻿<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"><html><head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" >
<meta http-equiv="Content-Language" content="tr" />
<title>naber panpa</title>
<meta name="title" content="naber panpa" />
<meta name="robots" content="index,follow,noarchive" />
<meta name="description" content="naber panpa" />
<meta name="keywords" content="naber panpa" />
<link rel="stylesheet" href="tpl/images/default.css" type="text/css" /> 
<link rel="icon" href="tpl//res/favicon_inci.png" type="image/x-icon" /> 
<link rel="shortcut icon" href="tpl//res/favicon_inci.png" type="image/x-icon" /> 
<script src="http://code.jquery.com/jquery-latest.js"></script>
<script src="http://www.sozlukspot.com/soy/ss_jslib.js?2" language="javascript" type="text/javascript" ></script>
</head>
<!--
sozlukspot.com up stats
server farm: kopernick
subd name: inci sözlük
up exeqution time: 0.0001 sec
server id: 7
start time: 21.12.2010 18:49:38
-->
<body  >
<h1 class="baslik_text"  ><a href="http://inci.sozlukspot.com/w/naber/"><span class="baslik_text">naber</span></a>&nbsp;<a href="http://inci.sozlukspot.com/w/panpa/"><span class="baslik_text">panpa</span></a>&nbsp;</h1><br><table width="160" border="0"  cellpadding="0" cellspacing="0" align="right"  style="float:right;clear:right;margin:0px;margin-left:3px;">
  <tr>
	<td>
	<script language="javascript">sspot_arastir('naber+panpa');</script>
	</td>
  </tr>

  <tr>
	<td>
 <div style="margin-top:10px;clear:both;text-align:center;" ></div><table width="160" height="600" border="0"  cellpadding="0" cellspacing="0" id="reklamlar" style="display:block;"  ><tr><td><iframe width="160" height="600" src="http://loft6151.serverloft.eu/soz_cls_googlead_alt.php?t=160x600&title=naber panpa" scrolling="no" frameborder="0" allowtransparency="true" ></iframe>
</td></tr></table>		</td>
	</tr>
</table>
<ol style="line-height:14pt;"  >
<?php $counter1=-1; if( isset($IYI_ENTRYLER) && is_array($IYI_ENTRYLER) && sizeof($IYI_ENTRYLER) ) foreach( $IYI_ENTRYLER as $key1 => $value1 ){ $counter1++; ?>
  <li  id="li_<?php echo $value1["id"];?>" style="margin-left:8px;"  ><?php echo $value1["entry"];?><div  style="text-align:right;font-size:8pt;" class="yazar_tarih">
(<a href="http://inci.sozlukspot.com/w/<?php echo $value1["yazar"];?>/" ><?php echo $value1["yazar"];?></a>, <?php echo $value1["tarih"];?>) <script language='javascript'>entry('12771814','fhsdfhsjdfhsdjfhsdjf','7973','okur','http://fhsdfhsjdfhsdjfhsdjf.sozlukspot.com');</script>    </div>
  </li>
<?php } ?>
</ol>
<hr />
<div align="center" >
&copy; 2010 - <a href="http://inci.sozlukspot.com/" target="_parent"  >inci sözlük</a><br /><br />

<div class="alttakiyazi"> inci sözlük bir interaktif sözlük çalışmasıdır. inci sözlük sözlük spot tematik sözlük servisi ile üretilmiştir. sözlükler yöneticilerinin sorumluluğundadır, www.sozlukspot.com sözlüklerin içeriklerinden sorumlu tutulamaz.</div>
</div>
<script language="javascript">sozlukspot_change_tit("inci sözlük - naber panpa");</script>
<!--
sozlukspot.com stats
server farm: kopernick
subd name: inci sözlük
exeqution time: 0.1967 sec
server id: 4
time: 21.12.2010 18:49:38
-->
</body>
</html>
