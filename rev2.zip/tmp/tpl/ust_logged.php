<?php if(!class_exists('raintpl')){exit;}?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>inci sözlük</title>
<meta name="title" content="<?php echo $SOZLUK_ADI;?>" />
<meta name="robots" content="index,follow,noarchive" />
<meta name="description" content="<?php echo $SOZLUK_ADI;?>" />
<meta name="keywords" content="<?php echo $SOZLUK_ADI;?>" />
<link rel="stylesheet" href="tpl/images/default.css" type="text/css" />
</head>
<body style="margin:0px;padding:0px;" class="ustframe" >
<table border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td valign="middle" title="" onclick="top.sportakisim.location.href='ss_about.php'"> <span class="logo_all" ><span class="logo_text" >inci sözlük</span></span></td>

    <td valign="middle">
    	<table height="23" border="0" cellpadding="2" cellspacing="1" style="margin:0;">
        <tr>
          <td  onmousedown="this.id='butDown';" onmouseout="this.id='';" onmousemove="this.id='butOver';" class="but"   >&nbsp;<a href="ss_leftframe.php?sa=rand" id="a_rand"   target="spsolkisim" >rastgele</a>&nbsp;</td>
          <td  onmousedown="this.id='butDown';" onmouseout="this.id='';" onmousemove="this.id='butOver';" class="but"  onclick="top.spsolkisim.location.href='ss_leftframe.php?sa=bir'" >&nbsp;<a href="ss_leftframe.php?sa=bir" id="a_birgun"  target="spsolkisim" >bir gün</a>&nbsp;</td>
		  <td  onmousedown="this.id='butDown';" onmouseout="this.id='';" onmousemove="this.id='butOver';" class="but"  title="inci sözlük le ilgili sik sorulan sorular" >&nbsp;<a href="/w/inci sözlük-ile-ilgili-sık-sorulan-sorular/"  id="a_faq" target="sportakisim" > asl? </a>&nbsp;</td>
<td   onmousedown="this.id='butDown';" onmouseout="this.id='';" onmousemove="this.id='butOver';" class="but"  colspan="3">&nbsp;<a href="ss_index.php?sa=istatistik" id="a_ista"  target="sportakisim" >istatistik</a>&nbsp;</td><td  onmousedown="this.id='butDown';" onmouseout="this.id='';" onmousemove="this.id='butOver';" class="but"  onclick="po('http://inci.sozlukspot.com/ss_index.php?sa=yzr&y=Claw','yazar_ben','340','450');"   >&nbsp;<a href="javascript:void(0);" onclick="po('http://inci.sozlukspot.com/ss_index.php?sa=yzr&y=Claw','yazar_ben','340','450');"  id="a_ben" target="sportakisim" title="ben: Claw"  >ben</a>&nbsp;</td><td   onmousedown="this.id='butDown';" onmouseout="this.id='';" onmousemove="this.id='butOver';" class="but"   onclick="top.sportakisim.location.href='ss_index.php?sa=msj'" >&nbsp;<a href="ss_index.php?sa=msj" id="a_msj"  target="sportakisim" >mesajlarım</a>&nbsp;</td><td  onmousedown="this.id='butDown';" onmouseout="this.id='';" onmousemove="this.id='butOver';" class="but"  >&nbsp;<a href="islem.php?islem=cikis" id="a_cikis" target="sportakisim"  
										title="" >exit</a>&nbsp;</td><td colspan="2"  onmousedown="this.id='butDown';" onmouseout="this.id='';" onmousemove="this.id='butOver';" class="but"  >&nbsp;<a href="ss_index.php?sa=ayar" id="a_ayar"  target="sportakisim" >hesabım</a>&nbsp;</td>        </tr>

        <tr>
          <td  onmousedown="this.id='butDown';" onmouseout="this.id='';" onmousemove="this.id='butOver';" class="but"    onclick="top.spsolkisim.location.href='ss_leftframe.php?sa=bugun'" title="bugünün basliklari" >&nbsp;<a href="ss_leftframe.php?sa=bugun" id="a_bugun"  target="spsolkisim" >bugün</a>&nbsp;</td>
          <td  onmousedown="this.id='butDown';" onmouseout="this.id='';" onmousemove="this.id='butOver';" class="but"   onclick="top.spsolkisim.location.href='ss_leftframe.php?sa=dun'" title="dünün basliklari" >&nbsp;<a href="ss_leftframe.php?sa=dun"  id="a_dun" target="spsolkisim" >dün</a>&nbsp;</td>
          <td  onmousedown="this.id='butDown';" onmouseout="this.id='';" onmousemove="this.id='butOver';" class="but"  onclick="top.spsolkisim.location.href='ss_leftframe.php?sa=gecen'" title="gecen yil bu zamanlar" >&nbsp;<a href="ss_leftframe.php?sa=gecen"  id="a_gecen" target="spsolkisim"  >2010</a>&nbsp;</td>          <td  onmousedown="this.id='butDown';" onmouseout="this.id='';" onmousemove="this.id='butOver';" class="but"  onclick="top.sportakisim.location.href='ss_index.php?sa=ortam" >&nbsp;<a href="ss_index.php?sa=ortam" id="a_ortam"  target="sportakisim" > sub-ethna </a>&nbsp;</td>
		  <td  onmousedown="this.id='butDown';" onmouseout="this.id='';" onmousemove="this.id='butOver';" class="but"  title="ukte" >&nbsp;<a href="ss_leftframe.php?sa=ukte"  id="a_ukte" target="spsolkisim" > ukte </a>&nbsp;</td>

          <td  onmousedown="this.id='butDown';" onmouseout="this.id='';" onmousemove="this.id='butOver';" class="but"  onclick="top.sportakisim.location.href='ss_entry.php?ne=su" title="şükela" >&nbsp;<a href="ss_entry.php?ne=su"  id="a_suke" target="sportakisim"  >:)</a>&nbsp;</td>
          <form name="getir_form" action="ss_entry.php" target="sportakisim" method="get" style="margin:0px;">
            <td colspan="3" valign="middle" nowrap="nowrap" id="td" style="height:16px;">başlık:
              <input name="k" type="text" style="font:7pt Verdana, sans-serif;" size="30" maxlength="100" />
              &nbsp;</td>
          </form>
          <td  onmousedown="this.id='butDown';" onmouseout="this.id='';" onmousemove="this.id='butOver';" class="but"  title="basliğin anlamini göster" >&nbsp;<a href="javascript:return sub1();" id="a_getir"  target="sportakisim"    onclick="return sub1();">getir</a>&nbsp;</td>
          <td  onmousedown="this.id='butDown';" onmouseout="this.id='';" onmousemove="this.id='butOver';" class="but"  title="bu basliği ara" >&nbsp;<a href="javascript:return sub2();" id="a_ara"  target="sportakisim"  onclick="return sub2();" >ara</a>&nbsp;</td>

        </tr>
      </table></td>