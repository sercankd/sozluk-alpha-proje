<?php if(!defined('IN_RAINTPL')){exit('Hacker attempt');}?><!-- info | www.raintpl.com 1.7.6 -->
Ciao, i am an included file :)
<!--/ info -->
